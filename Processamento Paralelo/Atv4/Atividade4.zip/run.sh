#!/bin/bash

#*********************************************************************#
# Antes de executar ./run.sh você deve dar perminsão para o arquivo   #
# possa ser executado. Para isso, execute o seginte comando:          #
#              chmod +x run.sh                                        #
#*********************************************************************#

numeroExecucoes=30

tamanhoMatriz="100 200 300 500 700"


for N in $tamanhoMatriz
do
	echo "N = "$N
	
	printf "\n["  >>Saida.txt
	for (( i=1; i<numeroExecucoes; i++ ))
	do
	# printf "\n["  >>Saida.txt
		./P4 "A_"$N".txt" "B_"$N".txt" 3 >>Saida.txt
	# printf "],"  >>Saida.txt
	done
	printf "]"  >>Saida.txt

	echo ""
done

for N in $tamanhoMatriz
do
	echo "N = "$N
	
	printf "\n["  >>Saida.txt
	for (( i=1; i<numeroExecucoes; i++ ))
	do
	# printf "\n["  >>Saida.txt
		./P4Paralel "A_"$N".txt" "B_"$N".txt" 3 >>Saida.txt
	# printf "],"  >>Saida.txt
	done
	printf "]"  >>Saida.txt

	echo ""
done

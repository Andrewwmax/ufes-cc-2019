//Aplica o filtro           
for(i=1;i<altura-1;i++)
 for(j=1;j<largura-1;j++)
    for (k=0; k<3; k++) {
        //Faz os calculos para aplicar o filtro
       aux1=1*(int)copia[i-1][j-1][k] + 2*(int)copia[i-1][j][k] + 1*(int)copia[i-1][j+1][k]
            + (-1)*(int)copia[i+1][j-1][k] + (-2)*(int)copia[i+1][j][k] + (-1)*(int)copia[i+1][j+1][k];

       aux2=1*(int)copia[i-1][j-1][k] + (-1)*(int)copia[i-1][j+1][k] + 2*(int)copia[i][j-1][k]
            + (-2)*(int)copia[i][j+1][k] + 1*(int)copia[i+1][j-1][k] + (-1)*(int)copia[i+1][j+1][k];
           

            aux3 = aux1*aux1 + aux2*aux2;

       imagem[i][j][k]=(unsigned char)(sqrt()); //Modifica o pixel
 }
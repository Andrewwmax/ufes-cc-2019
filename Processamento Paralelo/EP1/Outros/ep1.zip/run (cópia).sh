#!/bin/bash

#*********************************************************************#
# Antes de executar ./run.sh vocÃª deve dar perminsÃ£o para o arquivo #
# possa ser executado. Para isso, execute o seginte comando:          #
#              chmod +x run.sh                                        #
#*********************************************************************#

numeroExecucoes=10
#numT="1 2"
numT="2"


for N in $numT
do
	echo "N = "$N
	for (( i=1; i<=numeroExecucoes; i++ ))
	do
		./a.out $N.pnm >>saida$N.txt
	done
	echo ""
	echo ""
done

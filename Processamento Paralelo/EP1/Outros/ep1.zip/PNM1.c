#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <time.h>


double MyClock() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (tv.tv_sec * 1000000) + tv.tv_usec;
}





typedef struct {
	int altura, largura, threshold;
	unsigned char ***pixel;
} Imagem;


unsigned char*** aloca(int n, int m);

Imagem *readPNM(const char *nomeArquivo);

Imagem *copia_img(Imagem *principal);



void escurece(Imagem *img, int fator);

void salvaPNM(Imagem *img, char* nomeArquivo, int processo);


void realca(Imagem *imagem);
void sobel(Imagem *imagem);
void laplace(Imagem *imagem);
void meufiltro(Imagem *imagem);


int corrige(int valor){

	int result;

    if(valor<0){
    	result=0;
    }else if(valor>255){
    	result=255;
    }else{
	
		result = valor;

    }


	return result;
}


int main(int argc, char *argv[]) {

	double inicio = MyClock();


	if (argc != 2) {
        fprintf(stderr, "usage: prog image.pnm\n");
        exit(1);
    }

	Imagem *imagem = readPNM(argv[1]);
	//Imagem *imagem2 = copia_img(imagem);
	//Imagem *imagem3 = copia_img(imagem);
	//Imagem *imagem4 = copia_img(imagem);
	


    int pid = fork();

   if (pid < 0) { /* ocorreu erro na execu��o do Fork */
        fprintf(stderr, "fork failed\n");
        exit(1);
   }
   else if (pid == 0) { /* processo filho */
       int pidf = fork();
       if (pidf < 0) {
            fprintf(stderr, "fork failed\n");
            exit(1);
       }
       else if(pidf == 0){            

			sobel(imagem);
			salvaPNM(imagem, argv[1], 1);

       }
       else{
             //realca(imagem2);
			// salvaPNM(imagem2, argv[1], 2);
       }
   } 
   else {  //processo pai 
       int pidp = fork();
       if (pidp < 0) {
            fprintf(stderr, "fork failed\n");
            exit(1);
       }
       else if(pidp == 0){
			//laplace(imagem3);
			//salvaPNM(imagem3, argv[1], 3);
       }
       else{
			//meufiltro(imagem4);
			//salvaPNM(imagem4, argv[1], 4);
       }
       wait(NULL); /* pai espera o t�rmino dos filhos */
       if(pidp != 0){
            double tempoPar = (MyClock()-inicio)/CLOCKS_PER_SEC;
            printf(" Tempo total: %.5lf\n\n", tempoPar);
       }
   }




	free(imagem);
	//free(imagem2);
	//free(imagem3);
	//free(imagem4);

	return 0;
}

// Aloca memoria para uma matriz de dimencoes (N x M x 3)
unsigned char*** aloca(int n, int m) {
    int i, j;
    unsigned char ***M;
    M = (unsigned char***) malloc(n * sizeof(unsigned char**));
    for(i = 0; i < n; i++){
        M[i] = (unsigned char**) malloc(m * sizeof(unsigned char*));
        for(j = 0; j < m; j++){
        	M[i][j] = (unsigned char*) malloc(3 * sizeof(unsigned char)); 
        	M[i][j][0] = 0; //Vermelho
        	M[i][j][1] = 0; //Verde
        	M[i][j][2] = 0; //Azul
        }
    }
    if (!M) {
		fprintf(stderr, "Erro na alocacao da memoria\n");
		exit(1);
	}

    return M;
}

Imagem *readPNM(const char *nomeArquivo) {
	char buff[16];
	Imagem *img;
	FILE *fp;
	int c;
    fp = fopen(nomeArquivo, "r");

    if (fp == NULL) {
        fprintf(stderr, "Nao foi possivel abrir o arquivo %s\n", nomeArquivo);
        exit(1);
    }
    if (!fgets(buff, sizeof(buff), fp)) {
		perror("stdin");
		exit(1);
	}

	if (buff[0] != 'P' || buff[1] != '3') {
		fprintf(stderr, "Formato da imagem invalido (deve ser 'P3')\n");
		exit(1);
	}

	img = (Imagem *) malloc(sizeof(Imagem));
	if (!img) {
		fprintf(stderr, "Erro na alocacao da memoria\n");
		exit(1);
	}

	c = getc(fp);
	while (c == '#') {
		while (getc(fp) != '\n')
			;
		c = getc(fp);
	}

	ungetc(c, fp);
	if (fscanf(fp, "%d %d", &img->largura, &img->altura) != 2) {
		fprintf(stderr, "Tamanho da imagem invalido\n");
		exit(1);
	}

	if (fscanf(fp, "%d", &img->threshold) != 1) {
		fprintf(stderr, "Componente rgb invalido\n");
		exit(1);
	}

	while (fgetc(fp) != '\n')
		;

	img->pixel = aloca(img->altura+2, img->largura+2);

	if (!img) {
		fprintf(stderr, "Erro na alocacao da memoria\n");
		exit(1);
	}
	int r, g, b;
	for(int i = 1; i <= img->altura; i++){
        for(int j = 1; j <= img->largura; j++){
            fscanf(fp, "%d %d %d", &r, &g, &b);
            img->pixel[i][j][0] = (unsigned char)r;
            img->pixel[i][j][1] = (unsigned char)g;
            img->pixel[i][j][2] = (unsigned char)b;
            //printf("%d %d %d ", r, g, b);
        }
        //printf("\n");
    }

	return img;
}







Imagem *copia_img(Imagem *principal) {

	Imagem *img;


	img = (Imagem *) malloc(sizeof(Imagem));
	if (!img) {
		fprintf(stderr, "Erro na alocacao da memoria\n");
		exit(1);
	}

	img->pixel = aloca(principal->altura+2, principal->largura+2);

	img->altura = principal->altura;
	img->largura = principal->largura;


	img->threshold = principal->threshold;

	//printf("%d %d\n",img->altura, img->largura );

	for(int i = 1; i <= img->altura; i++){
        for(int j = 1; j <= img->largura; j++){
            img->pixel[i][j][0] = principal->pixel[i][j][0];
            img->pixel[i][j][1] = principal->pixel[i][j][1];
            img->pixel[i][j][2] = principal->pixel[i][j][2];
        }
    }





	return img;
}







void escurece(Imagem *imagem, int fator){
	for(int i = 1; i <= imagem->altura; i++)
      for(int j = 1; j <= imagem->largura; j++) 
      	for(int k = 0; k < 3; k++) {
	        int valor = (int)imagem->pixel[i][j][k];   //pega o valor do p�xel
	        valor -= fator;              //escurece o p�xel
	        if (valor<0)                 //se der negativo, deixa preto
	        	valor = 0;
            valor=(valor<0?0:valor);
	        imagem->pixel[i][j][k] = (unsigned char)valor;   //modifica o p�xel
      	}
}




void sobel(Imagem *imagem){
	


	int altura = imagem->altura, largura=imagem->largura;
	int i, j, k;
	int aux1, aux2;
	int x, y, z;

	Imagem *copia = (Imagem *) malloc(sizeof(Imagem));


	copia->pixel = aloca(imagem->altura+2, imagem->largura+2);

	 copia->altura = (int) imagem->altura;
	 copia->largura = (int) imagem->largura;

	  for(x = 1; x <= altura; x++){
      	for(y = 1; y <= largura; y++){ 
      		for(z = 0;z < 3; z++){      		
      		
      		//printf("%d\n", imagem->pixel[x][y][z]);

      		copia->pixel[x][y][z] = imagem->pixel[x][y][z];
			}
		}
	}	



	for(i=1;i<altura-1;i++)
	 for(j=1;j<largura-1;j++)
	    for (k=0; k<3; k++) {
	       


	        //Faz os calculos para aplicar o filtro
	       aux1=1*(int)copia->pixel[i-1][j-1][k] + 2*(int)copia->pixel[i-1][j][k] + 1*(int)copia->pixel[i-1][j+1][k]
	            + (-1)*(int)copia->pixel[i+1][j-1][k] + (-2)*(int)copia->pixel[i+1][j][k] + (-1)*(int)copia->pixel[i+1][j+1][k];

	       aux2=1*(int)copia->pixel[i-1][j-1][k] + (-1)*(int)copia->pixel[i-1][j+1][k] + 2*(int)copia->pixel[i][j-1][k]
	            + (-2)*(int)copia->pixel[i][j+1][k] + 1*(int)copia->pixel[i+1][j-1][k] + (-1)*(int)copia->pixel[i+1][j+1][k];
	       


	      imagem->pixel[i][j][k]=(unsigned char)(sqrt((aux1*aux1 + aux2*aux2))); //Modifica o pixel

	      //printf("%d\n", imagem->pixel[i][j][k]);

	 }

	//free(copia);

}



void realca(Imagem *imagem){

	int altura = imagem->altura, largura=imagem->largura;
	int i, j, k;
	int aux1, aux2, aux3;
	int x, y, z;

	Imagem *copia = (Imagem *) malloc(sizeof(Imagem));


	copia->pixel = aloca(imagem->altura+2, imagem->largura+2);

	 copia->altura = (int) imagem->altura;
	 copia->largura = (int) imagem->largura;

	  for(x = 1; x <= altura; x++){
      	for(y = 1; y <= largura; y++){ 
      		for(z = 0;z < 3; z++){      		
      		copia->pixel[x][y][z] = imagem->pixel[x][y][z];
			}
		}
	}	



	for(i=1;i<altura-1;i++){
	 for(j=1;j<largura-1;j++){
	    for (k=0; k<3; k++) {
	        //Faz os calculos para aplicar o filtro
	       aux1=(-1)*(int)copia->pixel[i-1][j][k] + (-1)*(int)copia->pixel[i][j-1][k] + 5 *(int)copia->pixel[i][j][k]
	            + (-1)*(int)copia->pixel[i][j+1][k]+ (-1)*(int)copia->pixel[i+1][j][k];

	           
	       imagem->pixel[i][j][k]=(unsigned char)(corrige(aux1)); //Modifica o pixel
	 }
	}
	}

	//free(copia);
}


void laplace(Imagem *imagem){

	int altura = imagem->altura, largura=imagem->largura;
	int i, j, k;
	int aux1, aux2, aux3;
	int x, y, z;

	Imagem *copia = (Imagem *) malloc(sizeof(Imagem));


	copia->pixel = aloca(imagem->altura+2, imagem->largura+2);

	 copia->altura = (int) imagem->altura;
	 copia->largura = (int) imagem->largura;

	  for(x = 1; x <= altura; x++){
      	for(y = 1; y <= largura; y++){ 
      		for(z = 0;z < 3; z++){      		
      		copia->pixel[x][y][z] = imagem->pixel[x][y][z];
			}
		}
	}	



	for(i=1;i<altura-1;i++){
	 for(j=1;j<largura-1;j++){
	    for (k=0; k<3; k++) {
	        //Faz os calculos para aplicar o filtro
	       aux1=(-1)*(int)copia->pixel[i-1][j][k] + (-1)*(int)copia->pixel[i][j-1][k] + 4 *(int)copia->pixel[i][j][k]
	            + (-1)*(int)copia->pixel[i][j+1][k]+ (-1)*(int)copia->pixel[i+1][j][k];

	           
	       imagem->pixel[i][j][k]=(unsigned char)(corrige(aux1)); //Modifica o pixel
	 }
	}
	}

	//free(copia);
}


void meufiltro(Imagem *imagem){

	int altura = imagem->altura, largura=imagem->largura;
	int i, j, k;
	int aux1, aux2, aux3;
	int x, y, z;

	Imagem *copia = (Imagem *) malloc(sizeof(Imagem));


	copia->pixel = aloca(imagem->altura+2, imagem->largura+2);

	 copia->altura = (int) imagem->altura;
	 copia->largura = (int) imagem->largura;

	  for(x = 1; x <= altura; x++){
      	for(y = 1; y <= largura; y++){ 
      		for(z = 0;z < 3; z++){      		
      		copia->pixel[x][y][z] = imagem->pixel[x][y][z];
			}
		}
	}	



	for(i=1;i<altura-1;i++){
	 for(j=1;j<largura-1;j++){
	    for (k=0; k<3; k++) {
	        //Faz os calculos para aplicar o filtro
	       aux1=(-1)*(int)copia->pixel[i-1][j][k] + (-1)*(int)copia->pixel[i][j-1][k] + 5 *(int)copia->pixel[i][j][k]
	            + (-1)*(int)copia->pixel[i][j+1][k]+ (-1)*(int)copia->pixel[i+1][j][k];

	           
	       imagem->pixel[i][j][k]=(unsigned char)(corrige(aux1)/2); //Modifica o pixel
	 }
	}
	}

	//free(copia);
}




void salvaPNM(Imagem *img, char* nomeArquivo, int processo){
	FILE *arquivo;
	int c, rgb_comp_color;
 	
 	char nome[200];
	char nomeSemExt[200];
	
	int i;
	int tam=strlen(nomeArquivo);
	for(i=0;i<tam-4;i++){
		nomeSemExt[i]=nomeArquivo[i];
	}


	sprintf(nome, "%s%d%s",nomeSemExt,"_Resultado_P",processo,".pnm");

    arquivo = fopen(nome, "w");
    fprintf(arquivo, "P3\n");
    fprintf(arquivo, "#Feita por Oberlan C. Romao\n");
    fprintf(arquivo, "%d %d %d\n", img->largura, img->altura, img->threshold);
    for(int i = 1; i <= img->altura; i++)
      for(int j = 1; j <= img->largura; j++) 
      	for(int k = 0; k < 3; k++)


      		fprintf(arquivo, "%d\n", (int)img->pixel[i][j][k]);
}

#!/bin/bash
reset
dot -Tpng -Kdot 12.DOT -o12.png -Gdpi=300
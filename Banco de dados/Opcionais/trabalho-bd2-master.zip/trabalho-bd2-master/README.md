Database project
============

This is a Java Project for the Database Class 2012. It was considered the best application developed during the semester.

## What it does?
It will create database and give the user an interface so the user can play with data. Its main goal was to test a great majority of SQL commands. Some Design patterns were used, like: Object Pool, Factory, and Singleton.

## Involved
* [@pablohpsilva](https://github.com/pablohpsilva)
* [@caiothomas](https://github.com/caiothomas)
* [@yuricampos](https://github.com/yuricampos)

--Relatorio 1
create index ind_estadoh on hospital(estado);



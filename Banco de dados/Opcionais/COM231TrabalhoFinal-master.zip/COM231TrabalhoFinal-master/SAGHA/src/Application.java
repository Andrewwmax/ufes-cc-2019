
import Controladores.ControlePrincipal;

/**
 *
 * @author Equipe de desenvolvimento SAGHA 
 */
public class Application {
    public static void main(String[] args) {
        ControlePrincipal controlador = new ControlePrincipal();
    }
}

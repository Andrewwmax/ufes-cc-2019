Trabalho computacional de Linguagens Formais e Autômatos, grupo 6, analisadores léxico e sintático da Linguagem Go
